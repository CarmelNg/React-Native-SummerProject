# Concept description

## _TITLE_ and description of the app

// Music Swap, music discovery app with a feature to find new music based off of a song/playlist. The idea is that it shows you very differnt/opposite music to that which you show.

## _WHO_ are the users you have in mind? (Add specifics or characteristics of the users) (> 50 words)

// The user who we have in mind are producers and or musical creative minds who want to broaden their horizons when it comes to music. It is for people who want to discover new music and get inspiration for their work without going out of their way to find it which is difficult. It can also be for people who want to have fun using the app and find weird songs they might enjoy.

## _WHAT_ problem will the app help the users to solve? (Describe various use cases) (> 50 words)

// The problem this app would solve is that when artists work, they often come to a creative block and become stuck. This app would help give inspiration and eleviate this issue in an easy and user freindly way. There isn't anything like this out there for people that want this. In fact, the complete opposite is implemented usually. For example, Spotify and other music platforms have a very defined algorithm which corners their users into certain genres/artists and only shows music similar or surrounding that. This in turn leads you to stay in this bubble of the same music you are already listening to and this would get tiring and boring.

## _HOW_ are users solving the problem now? (Without your app) (> 75 words)

Users are solving this problem now by going out of their way to research about new genres, or take long and unconvential ways to find random playlists and user profiles. They are also solving the problem now by mindlessly scrolling for quite some time until they find something new. For example, on Youtube, you can scroll forever and new entries will keep on popping up but it will always show something similar to what you are hearing. It is pretty rare to find that hidden gem that you stumble on from time to time.

## _HOW_ can the users solve the problem with your app? (> 75 words)

Users can solve this problem by using our app because we maximize the times you find that hidden gem. That special something that inspires you or interests you will be found by our app. You don't need to mindlessly scroll through youtube recommending you things you have already heard until you see something now.

## Show off your application’s _LOGO_:

// TODO: Add logo to repo and inline it here:

![App logo](./logo.png)
