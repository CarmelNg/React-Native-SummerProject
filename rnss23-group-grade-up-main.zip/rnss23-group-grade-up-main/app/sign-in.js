import { useState } from "react";
import {
  Text,
  View,
  TextInput,
  StyleSheet,
  Button,
  TouchableOpacity,
} from "react-native";
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import { Stack, useRouter } from "expo-router";
import { FontAwesome } from "@expo/vector-icons";

export default function SignIn() {
  const [mail, setMail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();

  const auth = getAuth();

  function handleSignIn() {
    signInWithEmailAndPassword(auth, mail, password)
      .then((userCredential) => {
        const user = userCredential.user;
        console.log(user);
        router.replace("/home");
      })
      .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
      });
  }
  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: "Sign In",
          headerTintColor: "#fff",
          headerStyle: {
            backgroundColor: "#264c59",
          },
        }}
      />

      <TouchableOpacity
        onPress={() => router.push("/users")}
        style={styles.returnButton}
      >
        <FontAwesome name="arrow-left" size={24} color="#264c59" />
      </TouchableOpacity>

      <Text style={styles.lineone}>Hey There,</Text>
      <Text style={styles.linetwo}>Welcome back</Text>
      <View style={styles.inputContainer}>
        <FontAwesome
          name="envelope"
          size={24}
          color="#ADA4A5"
          style={styles.icon}
        />
        <TextInput
          style={styles.input}
          onChangeText={setMail}
          value={mail}
          placeholder="Email"
          placeholderTextColor="#ADA4A5"
        />
      </View>
      <View style={styles.inputContainer}>
        <FontAwesome
          name="lock"
          size={24}
          color="#ADA4A5"
          style={styles.icon}
        />
        <TextInput
          style={styles.input}
          onChangeText={setPassword}
          value={password}
          secureTextEntry={true}
          placeholder="Password"
          placeholderTextColor="#ADA4A5"
        />
      </View>

      <View>
        <Text style={styles.forgotP}>Forgot your Password?</Text>
      </View>

      <Button
        title="Sign In"
        onPress={handleSignIn}
        style={styles.signinButton}
      >
        <Text style={styles.signinButtonText}>Sign in</Text>
      </Button>
      <View style={styles.footerContainer}>
        <Text style={styles.label}>Don't have an account yet?</Text>
        <TouchableOpacity onPress={() => router.push("/sign-up")}>
          <Text
            style={[
              styles.linkText,
              { textDecorationLine: "underline", color: "pink" },
            ]}
          >
            Register
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    backgroundColor: "#white",
    justifyContent: "center",
    alignItems: "center",
  },

  lineone: {
    color: "#1D1617",
    fontSize: 16,
    fontWeight: "400",
    lineHeight: 24,
    textAlign: "center",
  },

  linetwo: {
    color: "#1D1617",
    fontSize: 20,
    fontWeight: "700",
    lineHeight: 30,
    textAlign: "center",
  },

  label: {
    color: "#ADA4A5",
    fontSize: 14,
  },

  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#F7F8F8",
    backgroundColor: "#F7F8F8",
    borderRadius: 14,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  icon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    height: 48,
    fontSize: 16,
    color: "#000",
  },
  linkText: {
    fontSize: 25,
    color: "#264c59",
    textDecorationLine: "underline",
    marginBottom: 5,
  },
  forgotP: {
    fontSize: 12,
    fontFamily: "sans-serif",
    fontWeight: "500",
    lineHeight: 18,
    color: "#ADA4A5",
    textDecorationLine: "underline",
  },

  signinButton: {
    width: 315,
    height: 60,
    flexShrink: 0,
    backgroundColor: "#264c59",
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#95ADFE",
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.3,
    shadowRadius: 22,
    elevation: 5,
    marginBottom: 20,
  },

  signinButtonText: {
    color: "#FFF",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "700",
    lineHeight: 24,
  },
  buttonText: {
    marginLeft: 10,
    color: "#FFF",
    fontSize: 16,
    fontWeight: "700",
    lineHeight: 24,
  },

  footerContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  linkText: {
    fontSize: 14,
    color: "#264c59",
    textDecorationLine: "underline",
    marginLeft: 5,
  },

  returnButton: {
    position: "absolute",
    top: 10,
    left: 10,
    zIndex: 1,
  },
});
