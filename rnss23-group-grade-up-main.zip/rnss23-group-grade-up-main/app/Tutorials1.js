import React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useRouter } from "expo-router";

export default function Tutorials1() {
  function nextPage() {
    const router = useRouter();
    router.push("/Tutorials2");
  }
  return (
    <View style={styles.container}>
      <Image
        style={styles.Image}
        source={require("../assets/runningMan.png")}
      />
      <View style={styles.textContainer}>
        <Text style={styles.text}>Start your timer</Text>
        <Text style={styles.bodyText}>
          Start your timer and watch as Pomo grows while you work.
        </Text>
      </View>
      <Pressable style={styles.Eclipse} onPress={nextPage}>
        <Image source={require("../assets/button2.png")} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    padding: 24,
    flexDirection: "column",
    justifyContent: "space-between",
  },
  text: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "left",
  },
  Image: {
    height: 444,
    width: 360,
    margin: -65,
    padding: 0,
  },
  bodyText: {
    width: 315,
    marginTop: 15,
    color: "#7B6F72",
  },
  Eclipse: {
    width: 60,
    height: 60,
    bottom: 0,
    alignSelf: "flex-end",
  },
  textContainer: {},
});
