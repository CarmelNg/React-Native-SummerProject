import React, { useState } from "react";
import { View, TouchableOpacity } from "react-native";
import { FontAwesome } from "@expo/vector-icons";

export default function Button({ icon, onPress }) {
  return (
    <TouchableOpacity onPress={onPress}>
      <FontAwesome name={icon} size={40} color="black" />
    </TouchableOpacity>
  );
}
