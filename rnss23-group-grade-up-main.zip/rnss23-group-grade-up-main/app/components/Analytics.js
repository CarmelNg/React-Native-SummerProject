// Store data of the app on an array [userid, name, analyticsdata, ...]
//Retrieve data from the realtime database
