import React, { useState } from "react";
import { View, Text, StyleSheet, Button, Pressable } from "react-native";
import Slider, { SliderProps } from "@react-native-community/slider";
import { color } from "react-native-reanimated";
import { TouchableOpacity } from "react-native-gesture-handler";

export default function TimerSettings({
  workTime,
  setWorkTime,
  breakTime,
  setBreakTime,
  selectedCycleSetting,
  setSelectedCycleSetting,
}) {
  let buttons = [];
  for (let i = 1; i <= 4; i++) {
    buttons.push(
      <TouchableOpacity
        style={
          selectedCycleSetting == i ? styles.selectedButton : styles.button
        }
        key={i}
        onPress={() => {
          setSelectedCycleSetting(i);
        }}
      >
        <Text style={styles.buttonText}>{i}</Text>
      </TouchableOpacity>
    );
  }
  return (
    <View style={styles.container}>
      <View style={styles.slider}>
        <Text style={styles.sliderTitle}>Work Time</Text>

        <Text>{Math.floor(workTime / 60) + " m"}</Text>

        <Slider
          style={{ width: 200, height: 40 }}
          //minimumValue={5 * 60}
          minimumValue={Math.floor(1 * 60)}
          maximumValue={60 * 60}
          minimumTrackTintColor="#C58BF2"
          maximumTrackTintColor="#F7F8F8"
          thumbTintColor="#C58BF2"
          onValueChange={(value) => {
            setWorkTime(value);
          }}
          step={5 * 60}
          value={workTime}
        />
      </View>

      <View style={styles.slider}>
        <Text style={styles.sliderTitle}>Break Time</Text>

        <Text style={styles.sliderText}>{breakTime + " m"}</Text>

        <Slider
          style={{ width: 200, height: 40 }}
          minimumValue={5}
          maximumValue={30}
          minimumTrackTintColor="#EEA4CE"
          maximumTrackTintColor="#F7F8F8"
          thumbTintColor="#EEA4CE"
          onValueChange={(value) => setBreakTime(value)}
          step={5}
          value={breakTime}
        />
      </View>

      <Text>Cycles</Text>

      <View style={styles.buttonGroup}>{buttons}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  slider: {
    padding: 1,
    alignItems: "center",
    backgroundColor: "#F7F8F8",
    margin: 10,
    boxShadow: "3px 3px 3px rgba(29, 22, 23, 0.03)",
    borderRadius: 20,
    flexDirection: "row",
    width: 325,
    height: 78,
  },
  sliderTitle: {
    textAlign: "left",
    fontWeight: "bold",
    alignSelf: "center",
    paddingRight: 10,
  },
  buttonGroup: {
    width: 100,
    flexDirection: "row",
    justifyContent: "center",
    paddingHorizontal: 10,
  },

  buttonText: {
    textAlignVertical: "center",

    textAlign: "center",
  },

  button: {
    alignItems: "center",
    backgroundColor: "#F7F8F8",
    boxShadow: "3px 3px 3px rgba(29, 22, 23, 0.04)",
    marginHorizontal: 11,
    padding: 20,
    height: 54,
    width: 64,
    borderRadius: 20,
  },
  selectedButton: {
    alignItems: "center",
    backgroundColor: "#C58BF2",
    padding: 20,
    marginHorizontal: 11,
    height: 64,
    width: 64,
    borderRadius: 20,
  },
  sliderText: {
    fontSize: 14,
    fontWeight: "500",
  },
});
