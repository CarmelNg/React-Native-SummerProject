import { useEffect, useState } from "react";
import { View, Text, StyleSheet } from "react-native";

export default function Encouragement() {
  async function getQuote() {
    const response = await fetch("https://api.quotable.io/quotes/random");

    const data = await response.json();
    console.log(data);
    setQuote(data[0]);
  }

  const [quote, setQuote] = useState("");

  useEffect(() => {
    getQuote();
  }, []);

  return (
    <View>
      <Text style={styles.heading}>You Are Doing Great!</Text>
      <Text style={styles.content}>{quote.content}</Text>
      <Text style={styles.author}>{`- ${quote.author}`}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  heading: {
    fontSize: 30,
    padding: 20,
    alignSelf: "center",
    fontWeight: 700,
  },
  content: {
    fontSize: 15,
    paddingBottom: 10,
    color: "#7B6F72",
  },
  author: {
    color: "#7B6F72",
    textAlign: "center",
  },
});
