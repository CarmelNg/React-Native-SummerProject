//import * as Progress from "react-native-progress";
//import Image from "react-native-image-progress";
import { View, Image, Text, StyleSheet, VirtualizedList } from "react-native";
import { CountdownCircleTimer } from "react-native-countdown-circle-timer";
import TimerSettings from "./TimerSettings";
import Button from "./Button";
import Encouragement from "./Encouragement";
import { useState } from "react";
import stage1 from "../../assets/stage1.png";
import stage2 from "../../assets/stage2.png";
import stage3 from "../../assets/stage3.png";
import stage4 from "../../assets/pomo.png";

let colors = ["#004777", "#F7B801", "#A30000", "#A30000"];

export default function Timer(playPressed) {
  const [start, setStart] = useState(false);
  const [iconBtn, setIconBtn] = useState("play");
  const [isPlaying, setIsPlaying] = useState(false);
  const [inWorkCycle, setInWorkCycle] = useState(true);
  const [inBreakCycle, setInBreakCycle] = useState(false);
  const [currentTimerTime, setCurrentTimerTime] = useState(5 * 60);
  const [key, setKey] = useState(0);
  const [workSlider, setWorkSlider] = useState(30 * 60);
  const [shortBreakSlider, setShortBreakSlider] = useState(10);
  const [selectedCycle, setSelectedCycle] = useState(0);

  const [minutesLeft, setMinutesLeft] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(0);

  function handleWorkTimer(time) {
    setWorkSlider(time);
  }

  function updateWorkTimer(time) {
    setMinutesLeft(Math.floor(time / 60));
    setSecondsLeft(time - Math.floor(time / 60) * 60);
  }

  function DisplayTomato({ remainingTime }) {
    let currentImage = stage1;
    if (iconBtn == "stop") {
      if (remainingTime >= (workSlider / 4) * 3) {
        currentImage = stage1;
      } else if (remainingTime >= (workSlider / 4) * 2) {
        currentImage = stage2;
      } else if (remainingTime >= workSlider / 4) {
        currentImage = stage3;
      } else if (remainingTime <= workSlider / 4 && remainingTime > 0) {
        currentImage = stage3;
      } else if (remainingTime <= 0) {
        currentImage = stage4;
      }
    }

    return <Image source={currentImage} style={{ height: 150, width: 150 }} />;
  }

  function handleBreakTimer(time) {
    setShortBreakSlider(time);
  }

  const pressPlay = (key) => {
    if (selectedCycle == 0 && iconBtn == "play") {
      alert("Please input number of cycles");
    } else {
      if (isPlaying) {
        setIconBtn("play");
      } else if (!isPlaying) {
        setIconBtn("stop");
      }
      setIsPlaying(!isPlaying);
      setKey(key + 1);
    }
  };

  function timerComplete(totalTime) {
    //let elapsedTime = totalTime;
    if (selectedCycle > 0) {
      if (inWorkCycle) {
        setCurrentTimerTime(shortBreakSlider);
        setInWorkCycle(false);
      } else {
        setCurrentTimerTime(workSlider);
        setInWorkCycle(true);
      }
    }
  }
  return (
    <View style={styles.timer}>
      <View style={styles.countdownCircle}>
        <View>
          {isPlaying ? (
            <Text style={styles.cycleHeading}>Cycle {selectedCycle}</Text>
          ) : (
            <Text></Text>
          )}
        </View>
        <View>
          {/* { ? (
            <Text> You have {selectedCycle} cycles left</Text>
          ) : (
            <Text></Text>
          )} */}
        </View>

        <CountdownCircleTimer
          key={key}
          isPlaying={isPlaying}
          duration={workSlider}
          //the 4 colors defined at top of Timer.js
          colors={colors}
          strokeWidth={20}
          colorsTime={[
            (workSlider / 4) * 3,
            (workSlider / 4) * 2,
            workSlider / 4,
            0,
          ]}
          size={200}
          onUpdate={(remainingTime) => updateWorkTimer(remainingTime)}
          onComplete={(totalTime) => {
            timerComplete(totalTime);
          }}
        >
          {/* {() => displayTomato()} */}

          {(props) => {
            return <DisplayTomato remainingTime={props.remainingTime} />;
          }}
        </CountdownCircleTimer>
      </View>

      <View style={styles.timeLeftText}>
        {isPlaying ? (
          <Text>
            {minutesLeft} m {secondsLeft} s
          </Text>
        ) : (
          <Text></Text>
        )}
      </View>

      {/* if timer starts, hide the settings options */}
      {!isPlaying ? (
        <View style={styles.timerSettings}>
          <TimerSettings
            workTime={workSlider}
            setWorkTime={handleWorkTimer}
            breakTime={shortBreakSlider}
            setBreakTime={handleBreakTimer}
            selectedCycleSetting={selectedCycle}
            setSelectedCycleSetting={setSelectedCycle}
          />
        </View>
      ) : (
        <Encouragement />
      )}

      <View style={styles.button}>
        <Button icon={iconBtn} onPress={() => pressPlay(key)} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  timer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  countdownCircle: {},
  timerSettings: {
    flex: 1,
    backgroundColor: "red",
    justifyContent: "flex-end",
  },
  button: {
    paddingTop: 20,
  },
  cycleHeading: {
    fontSize: 20,
    textAlign: "center",
    padding: 10,
  },
});
