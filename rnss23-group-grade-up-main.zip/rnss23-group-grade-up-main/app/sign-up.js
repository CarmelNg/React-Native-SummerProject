import { useState, useEffect } from "react";
import {
  Text,
  View,
  TextInput,
  StyleSheet,
  Button,
  Alert,
  TouchableOpacity,
} from "react-native";
import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";
import { getDatabase, ref, set } from "firebase/database";
import { Stack, useRouter } from "expo-router";
import { FontAwesome } from "@expo/vector-icons";

export default function SignUp() {
  const [name, setName] = useState("");
  const [mail, setmail] = useState("");
  const [password, setPassword] = useState("");
  const [privacyPolicyAccepted, setPrivacyPolicyAccepted] = useState(false);
  const [showPrivacyPolicyAlert, setShowPrivacyPolicyAlert] = useState(false);
  const router = useRouter();

  const auth = getAuth();
  const database = getDatabase();

  function handleSignUp() {
    createUserWithEmailAndPassword(auth, mail, password)
      .then((userCredential) => {
        const user = userCredential.user;
        console.log(user);
        saveAdditionalUserData(user.uid, name, mail);
        router.replace("/home");
      })
      .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
      });
  }

  function saveAdditionalUserData(userId, name, mail) {
    const usersRef = ref(database, "users");

    const newUser = {
      mail: mail,
      name: name,
    };

    set(ref(usersRef, userId), newUser)
      .then(() => {
        console.log("Additional user data saved successfully");
      })
      .catch((error) => {
        console.error("Error saving additional user data:", error);
      });
  }

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: "Sign Up",
          headerTintColor: "#fff",
          headerStyle: {
            backgroundColor: "#264c59",
          },
        }}
      />
      <TouchableOpacity
        onPress={() => router.push("/users")}
        style={styles.returnButton}
      >
        <FontAwesome name="arrow-left" size={24} color="#264c59" />
      </TouchableOpacity>
      <Text style={styles.lineone}>Hey There,</Text>
      <Text style={styles.linetwo}>Create an account</Text>

      <View style={styles.inputContainer}>
        <FontAwesome
          name="user"
          size={24}
          color="#ADA4A5"
          style={styles.icon}
        />
        <TextInput
          style={styles.input}
          onChangeText={setName}
          value={name}
          placeholder="Name"
          placeholderTextColor="#ADA4A5"
        />
      </View>

      <View style={styles.inputContainer}>
        <FontAwesome
          name="envelope"
          size={24}
          color="#ADA4A5"
          style={styles.icon}
        />
        <TextInput
          style={styles.input}
          onChangeText={setmail}
          value={mail}
          placeholder="Email"
          placeholderTextColor="#ADA4A5"
        />
      </View>

      <View style={styles.inputContainer}>
        <FontAwesome
          name="lock"
          size={24}
          color="#ADA4A5"
          style={styles.icon}
        />
        <TextInput
          style={styles.input}
          onChangeText={setPassword}
          value={password}
          secureTextEntry={true}
          placeholder="Password"
          placeholderTextColor="#ADA4A5"
        />
      </View>

      <Text style={styles.checkboxLabel}>
        By continuing you accept our Privacy Policy and Term of Use.
      </Text>

      <Button
        title="Register"
        onPress={handleSignUp}
        style={styles.registerButton}
      >
        <Text style={styles.registerButtonText}>Register</Text>
      </Button>

      <View style={styles.footerContainer}>
        <Text style={styles.label}>Already have an account?</Text>
        <TouchableOpacity onPress={() => router.push("/sign-in")}>
          <Text
            style={[
              styles.linkText,
              { textDecorationLine: "underline", color: "pink" },
            ]}
          >
            Login
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    backgroundColor: "#white",
    justifyContent: "center",
    alignItems: "center",
  },
  label: {
    color: "#ADA4A5",
    fontSize: 14,
  },
  lineone: {
    color: "#1D1617",
    fontSize: 16,
    fontWeight: "400",
    lineHeight: 24,
    textAlign: "center",
  },
  linetwo: {
    color: "#1D1617",
    fontSize: 20,
    fontWeight: "700",
    lineHeight: 30,
    textAlign: "center",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#F7F8F8",
    backgroundColor: "#F7F8F8",
    borderRadius: 14,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  icon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    height: 48,
    fontSize: 16,
    color: "#000",
  },
  checkboxLabel: {
    color: "#ADA4A5",
    fontSize: 12,
    fontWeight: "400",
    lineHeight: 15,
    textAlign: "center",
    marginBottom: 20,
  },
  registerButton: {
    width: 315,
    height: 60,
    flexShrink: 0,
    backgroundColor: "#264c59",
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#95ADFE",
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.3,
    shadowRadius: 22,
    elevation: 5,
    marginBottom: 20,
  },
  registerButtonText: {
    color: "#FFF",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "700",
    lineHeight: 24,
  },
  footerContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  linkText: {
    fontSize: 14,
    color: "#264c59",
    textDecorationLine: "underline",
    marginLeft: 5,
  },
  returnButton: {
    position: "absolute",
    top: 10,
    left: 10,
    zIndex: 1,
  },
});
