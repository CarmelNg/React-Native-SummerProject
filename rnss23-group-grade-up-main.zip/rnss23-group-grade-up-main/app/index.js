// import React, { useState } from "react";
// import { View, Text, StyleSheet, Button, Pressable } from "react-native";
// import Slider, { SliderProps } from "@react-native-community/slider";
// import { color } from "react-native-reanimated";
// import { TouchableOpacity } from "react-native-gesture-handler";
//import TimerSettings from "./components/timerSettings";

// export default function App() {
//   return <TimerSettings />;
// }

import { useRouter } from "expo-router";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "../firebaseConfig";

export default function AppRoot() {
  const router = useRouter();

  onAuthStateChanged(auth, (user) => {
    console.log(user);
    if (user) {
      router.replace("/home");
    } else {
      router.replace("/onboarding");
    }
  });
}
