import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Alert,
  Image,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import {
  getAuth,
  deleteUser,
  onAuthStateChanged,
  signOut,
} from "firebase/auth";
import { getDatabase, ref, remove, onValue } from "firebase/database";
import userIcon from "../../../assets/userIcon.png";

export default function Users() {
  const navigation = useNavigation();
  const [user, setUser] = useState(null);
  const [loggedIn, setLoggedIn] = useState(false);
  const [userName, setUserName] = useState("");
  const API_URL = "https://testlogin-86df8-default-rtdb.firebaseio.com";

  useEffect(() => {
    const authInstance = getAuth();
    const unsubscribe = onAuthStateChanged(authInstance, (user) => {
      console.log(user);
      if (user) {
        setLoggedIn(true);
        setUserName(user.displayName || "");
        setUser(user);
      } else {
        setLoggedIn(false);
        setUserName("");
        setUser(null);
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      getUsers();
    }
  }, [user]);

  async function getUsers() {
    try {
      const database = getDatabase();
      const userRef = ref(database, `users/${user.uid}`);

      const snapshot = await new Promise((resolve, reject) => {
        onValue(userRef, resolve, reject);
      });

      const userData = snapshot.val();
      if (userData) {
        const user = {
          id: user.uid,
          ...userData,
        };
        setUser(user);
      }
    } catch (error) {
      console.log("Error fetching user data:", error.message);
    }
  }

  function handleLogin() {
    navigation.navigate("sign-in");
  }

  function handleSignUp() {
    navigation.navigate("sign-up");
  }

  function handleDeleteAccount() {
    Alert.alert(
      "Confirm Deletion",
      "Are you sure you want to delete your account?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Delete",
          style: "destructive",
          onPress: performAccountDeletion,
        },
      ]
    );
  }

  async function handleLogout() {
    try {
      const authInstance = getAuth();
      await signOut(authInstance);
      setUser(null);
      setLoggedIn(false);
      navigation.navigate("home");
    } catch (error) {
      console.log("Error logging out:", error.message);
    }
  }

  async function performAccountDeletion() {
    try {
      const authInstance = getAuth();
      const user = authInstance.currentUser;

      await deleteUser(user);

      const database = getDatabase();
      const userRef = ref(database, `users/${user.uid}`);
      await remove(userRef);

      navigation.navigate("sign-up");
    } catch (error) {
      console.log("Error deleting account:", error.message);
    }
  }

  return (
    <View style={styles.container}>
      {loggedIn ? (
        <>
          <View style={styles.imageContainer}>
            <Image source={userIcon} style={styles.userIcon} />
          </View>

          <Text style={styles.welcomeText}>You are currently logged In</Text>

          <TouchableOpacity onPress={handleLogout} style={styles.button}>
            <Text style={styles.buttonText}>Logout</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={handleDeleteAccount}
            style={styles.deleteButton}
          >
            <Text style={styles.deleteButtonText}>Delete Account</Text>
          </TouchableOpacity>
        </>
      ) : (
        <>
          <TouchableOpacity onPress={handleLogin} style={styles.button}>
            <Text style={styles.buttonText}>Login</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleSignUp} style={styles.button}>
            <Text style={styles.buttonText}>Sign up</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    backgroundColor: "#FFF",
  },
  imageContainer: {},
  welcomeText: {
    fontSize: 20,
    fontWeight: "500",
    marginBottom: 16,
  },
  deleteButton: {
    width: 315,
    paddingVertical: 12,
    paddingHorizontal: 16,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 8,
    backgroundColor: "#FF0000",
    marginBottom: 16,
  },
  deleteButtonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "500",
  },
  button: {
    width: 315,
    paddingVertical: 12,
    paddingHorizontal: 16,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 8,
    backgroundColor: "#C58BF2",
    marginBottom: 16,
  },
  buttonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "500",
  },

  logoutButton: {
    width: 315,
    paddingVertical: 12,
    paddingHorizontal: 16,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 8,
    backgroundColor: "#FF0000",
    marginBottom: 16,
  },
});
