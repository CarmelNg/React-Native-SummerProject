import React from "react";
import { StyleSheet, View, Text, FlatList, Image } from "react-native";
import { useEffect, useState } from "react";
import storeImage from "../../../assets/shopImages/store-title.png";
import storeCoins from "../../../assets/shopImages/balance.png";

export default function Shop() {
  const [shopItems, setShopItems] = useState([]);
  let keyx = 0;
  useEffect(() => {
    async function getShopItems() {
      const response = await fetch(
        "https://testlogin-86df8-default-rtdb.firebaseio.com/shop.json"
      );
      const dataObj = await response.json();
      const shopItemsArray = Object.keys(dataObj).map((key) => ({
        id: key,
        ...dataObj[key],
      })); // from object to array
      setShopItems(shopItemsArray);
    }

    getShopItems();
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.storeWrapper}>
        <Image style={styles.imageStore} source={storeImage} />
        <Image style={styles.imageCoins} source={storeCoins} />
      </View>
      <FlatList
        numColumns={2}
        key={keyx + 1}
        data={shopItems}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image style={styles.cardImage} source={{ uri: item.image }} />
          </View>
        )}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  text: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#000",
  },
  card: {
    // position: "absolute",
    display: "flex",
    elevation: 5,
    height: 125,
    width: 125,
    padding: 0,
    margin: 10,
    backgroundColor: "white",
    borderRadius: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
    justifyContent: "center",
  },
  cardImage: {
    // position: "relative",
    width: "60%",
    height: "100%",
    left: 40,
    top: 17,
    //justifyContent: "center",
  },
  imageStore: {
    width: 150,
    height: 50,
  },
  imageCoins: {
    width: 150,
    height: 50,
  },
  storeWrapper: {
    flexDirection: "row",
  },
});
