import React from "react";
import { StyleSheet, View, Text } from "react-native";
import { AntDesign } from "@expo/vector-icons";

export default function Shop() {
  return (
    <View style={styles.container}>
      <View style={styles.contentContainer}>
        <View style={styles.upgradeContainer}>
          <Text style={styles.upgradeText}>Upgrade to Premium</Text>
        </View>
        <View style={styles.priceContainer}>
          <Text style={styles.priceText}>$2.99/month</Text>
          <Text style={styles.priceText}>or</Text>
          <Text style={styles.priceText}>$19.99/year</Text>
        </View>
        <Text style={styles.subtitle}>Benefits included:</Text>
        <View style={styles.benefitContainer}>
          <View style={styles.benefit}>
            <AntDesign
              name="check"
              size={16}
              color="#4F9DF7"
              style={styles.checkIcon}
            />
            <Text style={styles.benefitText}>
              Get comprehensive analytics on your work and improvements.
            </Text>
          </View>
          <View style={styles.benefit}>
            <AntDesign
              name="check"
              size={16}
              color="#4F9DF7"
              style={styles.checkIcon}
            />
            <Text style={styles.benefitText}>
              Connect to your Canvas/Blackboard.
            </Text>
          </View>
          <View style={styles.benefit}>
            <AntDesign
              name="check"
              size={16}
              color="#4F9DF7"
              style={styles.checkIcon}
            />
            <Text style={styles.benefitText}>
              Receive notifications and alerts to keep you on track with your
              work.
            </Text>
          </View>
          <View style={styles.benefit}>
            <AntDesign
              name="check"
              size={16}
              color="#4F9DF7"
              style={styles.checkIcon}
            />
            <Text style={styles.benefitText}>
              Earn rewards with our School Master program.
            </Text>
          </View>
          <View style={styles.benefit}>
            <AntDesign
              name="check"
              size={16}
              color="#4F9DF7"
              style={styles.checkIcon}
            />
            <Text style={styles.benefitText}>
              Customize and style your avatar.
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  contentContainer: {
    backgroundColor: "#F8F8F8",
    borderRadius: 10,
    padding: 20,
    width: "90%",
  },
  upgradeContainer: {
    backgroundColor: "#C58BF2",
    borderRadius: 5,
    paddingVertical: 10,
    marginBottom: 20,
  },
  upgradeText: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#fff",
    textAlign: "center",
  },
  priceContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 10,
  },
  priceText: {
    fontSize: 16,
    color: "#fff",
    backgroundColor: "#264C59",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 5,
    marginHorizontal: 5,
  },
  subtitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#000",
    marginBottom: 10,
  },
  benefitContainer: {
    marginBottom: 20,
  },
  benefit: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 5,
  },
  checkIcon: {
    marginRight: 5,
  },
  benefitText: {
    fontSize: 16,
    color: "#000",
  },
});
