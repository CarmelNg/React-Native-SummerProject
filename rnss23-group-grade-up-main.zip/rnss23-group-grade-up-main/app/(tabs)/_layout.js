import { Ionicons } from "@expo/vector-icons";
import { Tabs } from "expo-router";

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerStyle: {
          backgroundColor: "#264c59",
        },
        headerTintColor: "#fff",
        headerTitleStyle: {
          fontWeight: "bold",
        },
        tabBarStyle: {
          backgroundColor: "#C58BF2",
        },
      }}
    >
      <Tabs.Screen
        name="home"
        options={{
          title: "Timer",
          tabBarActiveTintColor: "#264c59",
          tabBarInactiveTintColor: "#fff",
          tabBarActiveBackgroundColor: "#acc6c9",
          tabBarIcon: () => <Ionicons name="timer" size={24} color="white" />,
        }}
      />

      <Tabs.Screen
        name="analytics"
        options={{
          title: "Analytics",
          tabBarActiveTintColor: "#264c59",
          tabBarInactiveTintColor: "#fff",
          tabBarActiveBackgroundColor: "#acc6c9",
          tabBarIcon: () => (
            <Ionicons name="analytics-outline" size={24} color="white" />
          ),
        }}
      />

      <Tabs.Screen
        name="shop"
        options={{
          title: "Shop",
          tabBarActiveTintColor: "#264c59",
          tabBarInactiveTintColor: "#fff",
          tabBarActiveBackgroundColor: "#acc6c9",
          tabBarIcon: () => (
            <Ionicons name="card-outline" size={24} color="white" />
          ),
        }}
      />
      <Tabs.Screen
        name="users"
        options={{
          title: "Me",
          tabBarActiveTintColor: "#264c59",
          tabBarInactiveTintColor: "#fff",
          tabBarActiveBackgroundColor: "#acc6c9",
          tabBarIcon: () => <Ionicons name="person" size={24} color="white" />,
        }}
      />
    </Tabs>
  );
}
