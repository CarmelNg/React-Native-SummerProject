import React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useRouter } from "expo-router";

export default function Tutorials() {
  function nextPage() {
    const router = useRouter();
    router.push("/Tutorials1");
  }
  return (
    <View style={styles.container}>
      <Image
        style={styles.Image}
        source={require("../assets/womanWithPhone.png")}
      />
      <View style={styles.textContainer}>
        <Text style={styles.text}>Set Your Timer</Text>
        <Text style={styles.bodyText}>
          Set your pomodoro timer to your preferred break, short rest and long
          rest times.
        </Text>
      </View>
      <Pressable style={styles.Eclipse} onPress={nextPage}>
        <Image source={require("../assets/button1.png")} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    padding: 24,
    flexDirection: "column",
    justifyContent: "space-between",
  },
  text: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "left",
  },
  Image: {
    height: 444,
    width: 360,
    margin: -65,
    padding: 0,
  },
  bodyText: {
    width: 315,
    marginTop: 15,
    color: "#7B6F72",
  },
  Eclipse: {
    width: 60,
    height: 60,
    bottom: 0,
    alignSelf: "flex-end",
  },
  textContainer: {},
});
