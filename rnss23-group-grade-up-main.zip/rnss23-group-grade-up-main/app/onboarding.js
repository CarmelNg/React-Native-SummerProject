import React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { Link } from "expo-router";
import { Ionicons } from "@expo/vector-icons";

export default function OnboardingPage() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>
          Tomato Timer{" "}
          <Ionicons
            name="ios-timer"
            size={36}
            color="#c58bf2"
            style={styles.icon}
          />
        </Text>
        <Text style={styles.subtitle}>Help Pomo grow</Text>
      </View>

      <View style={styles.buttonsContainer}>
        <Link href="/home" style={styles.button}>
          <Text style={styles.buttonText}>Get Started</Text>
        </Link>
        <Link href="/Tutorials" style={styles.button}>
          <Text style={styles.buttonText}>Tutorial</Text>
        </Link>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    backgroundColor: "#FFF",
  },
  header: {
    flex: 26,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    color: "#1D1617",
    fontSize: 36,
    fontWeight: "bold",
    lineHeight: 44,
    fontFamily: "sans-serif",
    textAlign: "center",
  },
  subtitle: {
    color: "#7B6F72",
    fontSize: 18,
    fontWeight: "normal",
    lineHeight: 24,
    textAlign: "center",
  },
  buttonsContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "flex-end",
    marginBottom: 16,
  },
  button: {
    width: 315,
    height: 48,
    paddingVertical: 12,
    paddingHorizontal: 16,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 20,
    backgroundColor: "#C58BF2",
    marginBottom: 16,
    textAlign: "center",
  },
  buttonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "500",
    justifyContent: "center",
  },
  icon: {
    marginLeft: 10,
  },
});
