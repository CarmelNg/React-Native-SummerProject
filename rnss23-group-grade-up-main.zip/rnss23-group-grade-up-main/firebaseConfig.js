import AsyncStorage from "@react-native-async-storage/async-storage";
import { initializeApp } from "firebase/app";
import {
  getReactNativePersistence,
  initializeAuth,
} from "firebase/auth/react-native";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBhq-r5tbqsuD_8UA031ATKLJ8pge_DN1o",
  authDomain: "testlogin-86df8.firebaseapp.com",
  databaseURL: "https://testlogin-86df8-default-rtdb.firebaseio.com",
  projectId: "testlogin-86df8",
  storageBucket: "testlogin-86df8.appspot.com",
  messagingSenderId: "783052119554",
  appId: "1:783052119554:web:52cd8f4d6c79ee791ad11b",
};

const app = initializeApp(firebaseConfig);
export const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage),
});
