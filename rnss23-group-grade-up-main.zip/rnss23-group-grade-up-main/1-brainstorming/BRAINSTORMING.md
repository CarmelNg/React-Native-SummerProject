# Brainstorming session

## Carmel's post-its and sketches

![Carmel's post-its](./carmel-post-its.jpg)

![Carmel's sketches](./carmel-sketches.jpg)

## Jarl's post-its and sketches

![Jarl's post-its](./Jarl-post-its.jpg)

![Jarl's sketches](./Jarl-sketches.jpg)

## Ali's post-its and sketches

![Ali's post-its](./Ali-post-its.png)

![Ali's sketches](./Ali-sketches.png)
